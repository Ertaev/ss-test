<template>
	<div class="container">
		<el-alert
			title="Для указания нескольких меток для одной пары логин/пароль используйте разделитель ;"
			type="info"
			show-icon
			:closable="false"
		/>
	</div>
</template>
