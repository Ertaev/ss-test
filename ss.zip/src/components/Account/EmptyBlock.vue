<template>
	<div>
		<p>Добавьте учетные записи</p>
	</div>
</template>