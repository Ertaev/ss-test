<template>
	<el-row :gutter="20" class="head">
		<el-col style="max-width: 280px"><div class="grid-content">Метки</div></el-col>
		<el-col style="max-width: 280px"><div class="grid-content">Тип записи</div></el-col>
		<el-col style="max-width: 280px"><div class="grid-content">Логин</div></el-col>
		<el-col style="max-width: 280px"><div class="grid-content">Пароль</div></el-col>
	</el-row>
</template>

<style scoped>
.head {
	margin-bottom: 12px;
}
</style>